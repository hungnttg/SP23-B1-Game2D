using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Ong : MonoBehaviour
{
    public float speed;//toc do
    public int numOfBG;
    private float max;
    private float min;
    private float khoangCachX;
    void Start()
    {
        this.max = 0.35f;
        this.min = -0.35f;
        this.speed = 0.5f;
        this.khoangCachX = 1f;
        //random vi tri truc y
        Vector3 pos = transform.position;
        pos.y = Random.Range(min, max);//lay vi tri ngau nhien cua y
        transform.position = pos;
    }

    // Update is called once per frame
    void Update()
    {
        //di chuyen
        transform.Translate(Vector3.left * speed * Time.deltaTime);
    }
    //tao 1 block moi khi va cham voi BGLooper
    private void OnTriggerEnter2D(Collider2D collision)
    {
        if(collision.name=="BGLooper")
        {
            Vector3 p = this.transform.position;
            p.x += khoangCachX * numOfBG;
            p.y += Random.Range(min, max);//tao do tho thut cua ong nuoc
            transform.position = p;
        }    
    }
}
