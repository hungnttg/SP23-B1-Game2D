using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GOScript : MonoBehaviour
{
    enum TrangThai
    {
        PLAY,RUNNING,DEATH
    }
    public static bool isPlay = false;
    public BirdScript player;
    private TrangThai tt;
    void ChangeState(TrangThai tr)
    {
        switch(tr)
        {
            case TrangThai.PLAY:
                Time.timeScale = 0;
                GetComponent<SpriteRenderer>().enabled = true;//hien thi Game Over
                break;
            case TrangThai.RUNNING:
                Time.timeScale = 1;
                GetComponent<SpriteRenderer>().enabled = false;//tat gameOver
                break;
            case TrangThai.DEATH:
                Time.timeScale = 0;
                GetComponent<SpriteRenderer>().enabled = true;//hien thi Game Over
                break;
        }
        this.tt = tr;//gan trang thai
    }
    
    void Start()
    {
        //vao game chay luon
        if (isPlay)
            ChangeState(TrangThai.PLAY);
        isPlay = true;
    }

    // Update is called once per frame
    void Update()
    {
        //neu chua chay-> chuyen sang running
        if ((Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0))
            && this.tt != TrangThai.RUNNING)
        {
            ChangeState(TrangThai.RUNNING);//can chuyen sang running
        }
        //neu chim chet
        if (player.dead && this.tt != TrangThai.DEATH)
        {
            ChangeState(TrangThai.DEATH);//can chuyen sang Chet
            Application.LoadLevel(Application.loadedLevel);
        }
        //neu da chet roi-> chuyen sang running
        if(tt==TrangThai.DEATH)
        {
            if (Input.GetKeyDown(KeyCode.Space) || Input.GetMouseButtonDown(0)
           && this.tt != TrangThai.RUNNING)
            {
               // ChangeState(TrangThai.RUNNING);
                // Time.timeScale = 1;//cho game tiep tuc
                Application.LoadLevel(Application.loadedLevel);
               

            }
        }
    }
}
