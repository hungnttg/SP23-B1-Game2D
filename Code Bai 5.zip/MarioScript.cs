using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class MarioScript : MonoBehaviour
{
    public static bool isGameOver = false;
    public float speedX, speedY;//toc do theo truc X,Y
    private Animator player;//nhan vat

    public Text txtScore;//text hien thi
    int score = 0;//diem
    void Start()
    {
        txtScore = GameObject.Find("txtDiem").GetComponent<Text>();//anh xa
        player = GetComponent<Animator>();//giong findViewByID
        //thiet lap cho player dung yen
        player.SetBool("isChay", false);
        player.SetBool("isDung", true);
    }
    private void OnCollisionEnter2D(Collision2D collision)
    {
        if(collision.gameObject.tag=="CoinTag")//neu va cham voi tag
        {
            score++;//tang diem
            Destroy(collision.gameObject);//huy coin
            txtScore.text = "Score: " + score.ToString();
        }    
    }
    void Update()
    {
        if(!isGameOver)
        {
            if(Input.GetKey(KeyCode.LeftArrow))//nhan mui ten trai
            {
                //player hoat dong dung yen
                player.SetBool("isChay", true);
                player.SetBool("isDung", false);
                //di chuyen
                gameObject.transform.Translate(Vector2.left * speedX * Time.deltaTime);
                //quay dau neu nguoc chieu
                if(gameObject.transform.localScale.x >0)
                {
                    gameObject.transform.localScale
                        = new Vector2(gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y);
                }
            }
            else if (Input.GetKey(KeyCode.RightArrow))//nhan mui ten phai
            {
                //player hoat dong dung yen
                player.SetBool("isChay", true);
                player.SetBool("isDung", false);
                //di chuyen
                gameObject.transform.Translate(Vector2.right * speedX * Time.deltaTime);
                //quay dau neu nguoc chieu
                if (gameObject.transform.localScale.x < 0)
                {
                    gameObject.transform.localScale
                        = new Vector2(gameObject.transform.localScale.x * -1,
                        gameObject.transform.localScale.y);
                }
            }
            else if(Input.GetKey(KeyCode.Space))//nhan dau cach
            {
                //player hoat dong dung yen
                player.SetBool("isChay", true);
                player.SetBool("isDung", false);
                //nhan vat bay
                //neu muon nhay-> can dieu kien kiem tra mat san
                //if(gameObject.tag=="matsan")
                gameObject.GetComponent<Rigidbody2D>().velocity
                    = new Vector2(gameObject.GetComponent<Rigidbody2D>().velocity.x,
                    speedY);
            }
            else
            {
                //player khong hoat dong
                player.SetBool("isChay", false);
                player.SetBool("isDung", true);
            }
        }
    }
}
