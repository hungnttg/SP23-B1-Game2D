using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Camerafollow : MonoBehaviour
{
    // khai bao player
    private Transform player;
    void Start()
    {
        //anh xa player
        player = GameObject.Find("PlayerM").transform;//findViewById
    }

    // hoán đổi vị trí
    void Update()
    {
        Vector3 pos = transform.position;
        pos.x = player.position.x;
        transform.position = pos;
    }
}
